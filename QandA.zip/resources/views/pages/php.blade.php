@extends('layouts.master')

@section('noidung')
<h2>fhudhsf<h2>
@endsection