<?php $__env->startSection('content'); ?>
    

    <?php if(session('thongbao')): ?>

        <div class="alert alert-success">
            <?php echo e(session('thongbao')); ?>

        </div>

    <?php endif; ?>
    <h2>Danh sách phiên hỏi đáp</h2>
    <form method = "get" action= "<?php echo e(route('search_session')); ?>" id="searchForm" role="search">
            <input type="hidden" name="_token" value ="<?php echo e(csrf_token()); ?>";>
            <div class="input-group" style="margin: 10px 0 29px 0; width: 40%"> 
                <input  type="text" class="form-control"  name="tukhoa" placeholder="Tìm kiếm..." >
                <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                
            </div>
    </form>
    <table border="2" class="table table-striped">
      
        <tr id="tbl-first-row">
            <td width="10%">ID phiên</td>
            <td width="10%">ID người dùng</td>
            <td width="50%">Tên phiên</td>
            <td width="10%">Tạo câu hỏi</td>
            <td width="10%">Hoạt động</td>
            <td width="5%">Sửa</td>
            <td width="5%">Xóa</td>
        </tr>

        
        <?php $__currentLoopData = $list_session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($l->id); ?></td>
                <td><?php echo e($l->user_id); ?></td>
                <td><?php echo e($l->name_session); ?></td>
                <td><a href="<?php echo e(url("admin/session/add_question/{$l->id}")); ?>">Tạo</a></td>
                <td> 
                    <form action="" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>    
                        <select id ="select" name="option">
                            <option <?php echo e(old('option',$l->active)=="1"? 'selected':''); ?> value="<?php echo e($l->active); ?>"                             
                                >Mở</option>
                            <option <?php echo e(old('option',$l->active)=="0"? 'selected':''); ?> value="<?php echo e($l->active); ?>"       
                                >Đóng</option>
                        </select>
                        <noscript>
                            <input type="submit" name="submit">
                        </noscript>
                    </form>
                </td>
                <td><a href="<?php echo e(url("admin/session/edit/{$l->id}")); ?>">Sửa</a></td>
                <td><a onclick="return xacnhanxoa('Bạn Có Chắc Là Muốn Xóa Không?')" 
                    href="<?php echo e(url("admin/session/delete_session/{$l->id}")); ?>">Xóa</a></td>
            </tr>

            <?php 
                if(isset($_POST['submit'])){
                    
                }

            ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
    
    <div aria-label="Page navigation">
        <?php echo e($list_session->links()); ?>

    </div>

    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/session/list_session.blade.php ENDPATH**/ ?>