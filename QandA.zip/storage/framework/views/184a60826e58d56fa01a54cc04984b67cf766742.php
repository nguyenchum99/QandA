<?php $__env->startSection('content'); ?>


    <div class="row">
                            
        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" style="padding-left: 30px">
            <center>
                <img src="<?php echo e(URL::asset('/img/avatars/'.Auth::user()->avatar)); ?>" alt="avatar">
                <a href="<?php echo e(url("user/profile")); ?>">
                <input type="submit" class="btn nut" value="Thay ảnh đại diện" style="background-color: #365899;color:white">
                </a>
            </center>
        </div>
        
        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
            <span class="fa fa-user name" ></span>
            <p class="name"> <?php echo e($user->name); ?></p>
            
            <span class="fa fa-graduation-cap" ></span>
            <p class="number">

                <?php if($user->level == 1): ?>
                    <?php echo e("Chức vụ: Quản trị viên"); ?>

                <?php else: ?> 
                    <?php echo e("Chức vụ: Thành viên"); ?>

                <?php endif; ?>
                
            </p>
            <span class="fa fa-question-circle-o" ></span>
            <p class="number"> Tổng số câu hỏi: <?php echo e($question); ?></p>
            <span class="fa fa-hourglass-half" ></span>
            <p class="number"> Câu hỏi chưa được trả lời: 0</p>
            <span class="fa fa-history" ></span>
            <p class="reload"> Lần cuối đặt câu hỏi: N/A</p>
        </div>
        
    </div>
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/user/user_info.blade.php ENDPATH**/ ?>