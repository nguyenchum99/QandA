<?php $__env->startSection('content'); ?>
    
    <table border="2" class="table table-striped">
        <h4>Tìm kiếm : <?php echo e($tukhoa); ?></h4>
        <tr id="tbl-first-row" style="font-weight: bold;">
                <td width="8%">ID phiên</td>
                <td width="13%">ID người dùng</td>
                <td width="68%">Tên phiên</td>
                <td width="5%">Sửa</td>
                <td width="5%">Xóa</td>
            </tr>

        
        <?php $__currentLoopData = $session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($l->id); ?></td>
                <td><?php echo e($l->user_id); ?></td>
                <td><?php echo e($l->name_session); ?></td>
                <td><a href="#">Sửa</a></td>
                <td><a onclick="return xacnhanxoa('Bạn Có Chắc Là Muốn Xóa Không?')" href="<?php echo e(url("admin/session/delete_session/{$l->id}")); ?>">Xóa</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/session/search_session.blade.php ENDPATH**/ ?>