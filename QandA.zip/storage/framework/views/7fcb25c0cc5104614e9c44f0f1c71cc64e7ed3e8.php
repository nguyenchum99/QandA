<?php $__env->startSection('content'); ?>
    

    <?php if(session('thongbao')): ?>

        <div class="alert alert-success">
            <?php echo e(session('thongbao')); ?>

        </div>

    <?php endif; ?>
    <h2>Danh sách câu hỏi</h2>

    <form method = "get" action= "<?php echo e(route('search_question')); ?>" id="searchForm" role="search">
            <input type="hidden" name="_token" value ="<?php echo e(csrf_token()); ?>";>
            <div class="input-group" style="margin: 10px 0 29px 0; width: 40%"> 
                <input  type="text" class="form-control"  name="tukhoa" placeholder="Tìm kiếm..." >
                <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                
            </div>
    </form>
    
    <table border="2" class="table table-striped">
       
        <tr id="tbl-first-row" style="font-weight: bold;">
            <td width="10%">ID câu hỏi</td>
            <td width="13%">ID người dùng</td>
            <td width="12%">ID phiên</td>
            <td width="45%">Câu hỏi</td>
            <td width="15%">Tạo câu trả lời</td>
            <td width="5%">Sửa</td>
            <td width="5%">Xóa</td>
        </tr>

        
        <?php $__currentLoopData = $list_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($l->id); ?></td>
                <td><?php echo e($l->user_id); ?></td>
                <td><?php echo e($l->session_id); ?></td>
                <td><?php echo e($l->question); ?></td>
                <td><a href="<?php echo e(url("admin/question/add_answer/{$l->id}")); ?>">Tạo</a></td>
                <td><a href="<?php echo e(url("admin/question/edit/{$l->id}")); ?>">Sửa</a></td>
                <td><a onclick="return xacnhanxoa('Bạn Có Chắc Là Muốn Xóa Không?')" href="<?php echo e(url("admin/question/delete/{$l->id}")); ?>">Xóa</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
    
    <div aria-label="Page navigation">
        <?php echo e($list_question->links()); ?>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/question/list_question.blade.php ENDPATH**/ ?>