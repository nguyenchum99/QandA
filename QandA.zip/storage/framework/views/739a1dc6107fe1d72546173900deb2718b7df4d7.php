<!DOCTYPE html>
<html>
<head>
    <title>The Login Form</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login_admin_style.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <base href="<?php echo e(asset('')); ?>" >
    <style>
    </style>
</head>
<body>
    
    
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        
            <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($err); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    <?php endif; ?>

    
    <?php if(session('thongbao')): ?>

    <div class="alert alert-success">
        <?php echo e(session('thongbao')); ?>

    </div>
    
    <?php endif; ?>

    <div class="wrap" style="background-color: #E9EBEE">
        <form role="form" class="login-form" action="<?php echo e(url("admin/login")); ?>" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
            <div class="form-header">
                <h3>Chào mừng Quản trị viên</h3>
            </div>
            
                    <div class="form-group">
                        <input type="text" class="form-input" placeholder="Tên đăng nhập" name="name" value="">
                    </div>
                
                    <div class="form-group">
                        <input type="password" class="form-input" placeholder="Mật khẩu" name="password">
                    </div>
                
                    <div class="form-group">
                        <button class="form-button" type="submit">Đăng nhập</button>
                    </div>
        
        </form>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/login.blade.php ENDPATH**/ ?>