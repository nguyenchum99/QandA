


    <ul class="list-group nav-bar">
        
        <li class="slide"><a href="<?php echo e(url('admin/user/listuser')); ?>" class="list-group-item">Quản lý người dùng</a>
            <ul class="list-group" id="menu">
                <li class="list-group-item"><a href="<?php echo e(url('admin/user/listuser')); ?>" style="text-decoration: none;">Danh sách người dùng</a></li>
                <li class="list-group-item"><a href="<?php echo e(url('admin/user/adduser')); ?>" style="text-decoration: none;">Thêm tài khoản mới</a></li>
            </ul>
        </li>

        <li class="slide"><a href="<?php echo e(url('admin/session/list_session')); ?>" class="list-group-item">Phiên hỏi đáp</a>
          
            <ul class="list-group" id="menu">
                    <li class="list-group-item"><a href="<?php echo e(url('/admin/session/list_session')); ?>" style="text-decoration: none;">Danh sách phiên</a></li>
                    <li class="list-group-item"><a href="<?php echo e(url('/admin/session/add_session')); ?>" style="text-decoration: none;">Thêm phiên hỏi đáp mới</a></li>
            </ul>
         
        </li>

        <li class="slide"><a href="<?php echo e(url('admin/question/listquestion')); ?>" class="list-group-item ">Quản lý câu hỏi</a>
        </li>

        <li class="slide"><a href="<?php echo e(url('admin/answer/listanswer')); ?>" class="list-group-item">Quản lý câu trả lời</a>
        </li>


    </ul><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>