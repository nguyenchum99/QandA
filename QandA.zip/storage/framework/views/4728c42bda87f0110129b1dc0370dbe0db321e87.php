<?php $__env->startSection('content'); ?>
    
    <table class="table table-striped">
        <h4>Tìm kiếm : <?php echo e($tukhoa); ?></h4>
        <tr id="tbl-first-row">
                <td width="12%">ID câu hỏi</td>
                <td width="12%">ID người dùng</td>
                <td width="12%">ID phiên</td>
                <td width="60%">Câu hỏi</td>
                <td width="5%">Sửa</td>
                <td width="5%">Xóa</td>
        </tr>

        
        <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($l->id); ?></td>
                <td><?php echo e($l->user_id); ?></td>
                <td><?php echo e($l->session_id); ?></td>
                <td><?php echo e($l->question); ?></td>
               
                <td><a href="<?php echo e(url("admin/question/edit/{$l->id}")); ?>">Sửa</a></td>
                <td><a href="<?php echo e(url("admin/question/delete/{$l->id}")); ?>">Xóa</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/question/search_question.blade.php ENDPATH**/ ?>