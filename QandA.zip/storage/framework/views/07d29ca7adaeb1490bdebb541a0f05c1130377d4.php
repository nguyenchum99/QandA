<?php $__env->startSection('content'); ?>
    
        
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            
                <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($err); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <?php endif; ?>

        
        <?php if(session('thongbao')): ?>

        <div class="alert alert-success">
            <?php echo e(session('thongbao')); ?>

        </div>
        <?php endif; ?>
        <h2>Danh sách người dùng</h2>
        <form method = "get" action= "<?php echo e(route('search_user')); ?>" id="searchForm" role="search">
                <input type="hidden" name="_token" value ="<?php echo e(csrf_token()); ?>";>
                <div class="input-group" style="margin: 10px 0 29px 0; width: 40%"> 
                    <input  type="text" class="form-control"  name="tukhoa" placeholder="Tìm kiếm..." >
                    <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                    
                </div>
        </form>

    <table border="2" class="table table-striped">
        
        <tr id="tbl-first-row" style="font-weight: bold;">

            <td width="12%">ID</td>
            <td width="30%" style="white-space: nowrap ;">Tên đăng nhập</td>
            <td width="40%">E-mail</td>
            
            <td width="10%">Ảnh đại diện</td>
            <td width="5%">Quyền</td>
            <td width="5%">Sửa</td>
            <td width="5%">Xóa</td>

        </tr>
        

        
        <?php $__currentLoopData = $list_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->id); ?></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?></td>
                
                <td><?php echo e($u->avatar); ?>

                <td>
                        <?php if($u->level == 1): ?>
                            <?php echo e("Admin"); ?>

                        <?php else: ?>
                            <?php echo e("User"); ?>

                        <?php endif; ?>
                </td>
                <td><a href="<?php echo e(url("admin/user/edit/{$u->id}")); ?>">Sửa</a></td>
                <td><a onclick="return xacnhanxoa('Bạn Có Chắc Là Muốn Xóa Không?')" href="<?php echo e(url("admin/user/delete/{$u->id}")); ?>">Xóa</a></td>
            </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </table>
    
    <div aria-label="Page navigation">
        <?php echo e($list_user->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/user/list_user.blade.php ENDPATH**/ ?>