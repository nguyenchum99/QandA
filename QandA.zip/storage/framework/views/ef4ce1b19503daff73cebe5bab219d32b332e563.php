<?php $__env->startSection('content'); ?>


<div class="main-right">
    <h2>Phiên hỏi đáp của tôi</h2>
    <?php if(session('thongbao')): ?>

    <div class="alert alert-success">
        <?php echo e(session('thongbao')); ?>

    </div>

<?php endif; ?>
       
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="box">

             
                <div class="row">  
                    <div class="col-md-2">
                        <img src="<?php echo e(URL::asset('/img/q-and-a.jpg')); ?>" alt="image" style="height: 75px;width:75px;margin-top:10px" >
                    </div>
                    <div class="col-md-10 box-right">
                        <p class="title" style="color: red">Phiên hỏi đáp: <?php echo e($l ->name_session); ?></p>
                        <p>
                            <?php if($l->active == 1): ?>
                            <?php echo e("Phiên hỏi đáp mở"); ?>    
                            <?php else: ?> 
                            <?php echo e("Phiên hỏi đáp đóng"); ?>

                            <?php endif; ?>
                        </p>
                        <p><a href="<?php echo e(url("user/manage/edit/{$l->id}")); ?>" >Sửa phiên</a></p>
                        <p><a href="<?php echo e(url("user/manage/delete/{$l->id}")); ?>" >Xóa phiên</a></p>
                        <p><a href="<?php echo e(url("user/manage/create_question/{$l->id}")); ?>" >Tạo câu hỏi</a></p>
                    </div>
                </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/manage/list_session_user.blade.php ENDPATH**/ ?>