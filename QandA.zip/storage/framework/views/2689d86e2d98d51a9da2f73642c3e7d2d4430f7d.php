<?php $__env->startSection('content'); ?>

<div class="top">
        <div class="row"> <center>
            <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                <img src="<?php echo e(URL::asset('/img/q-and-a.jpg')); ?>">
            </div></center>
            <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">
                <p style="color: red;font-size: 18px;"><span class="fa fa-lock">
                </span>Phiên hỏi đáp</p>
                <p><span class="fa fa-lock">
                </span>Mô tả: Phiên hỏi đáp thử nghiệm</p>
                <p><span class="fa fa-lock">
                </span>Đăng bới: </p>
                <p><span class="fa fa-lock">
                </span>Thời gian tạo:22 ngày trước</p>
            </div>
        </div>
</div>

<div class="botton">
    <div class="header">
        <p class="title">Đăng bới: Thành viên ẩn danh</p>
        <p class="time">22 ngày trước</p>
    </div>
    <div class="main-right">
       
        <div class="content">
            
            <div class="noidung">
                <ul>
                    <li >Nội dung câu hỏi:</li>
                    <li><?php echo e($list_question->question); ?></li>
                    <li>3 lượt thích</li>
                </ul>

            </div>


            <p><i class="fa fa-thumbs-o-up"></i> Thích</p>
            
            <?php $__currentLoopData = $list_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="tra-loi">
                    <ul>
                        <li style="background: #1a88d652"><p><span class="fa fa-user"> Người dùng: <?php echo e($l->user_id); ?></span></p>
                        <br>
                        <p class="time">22 ngày trước</p></li>
                        <li><?php echo e($l->answer); ?></li>
                    </ul>
                </div>
                    

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/page/demo.blade.php ENDPATH**/ ?>