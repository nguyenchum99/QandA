<?php $__env->startSection('content'); ?>

        <div style ="width: 40%">
            <h2>Thay đổi thông tin </h2>
        	 
             <?php if(count($errors) > 0): ?>
             <div class="alert alert-danger">
             
                 <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($err); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             </div>
          <?php endif; ?>


            <form method="post" action="<?php echo e($user->id); ?>">

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                <div class="form-group">
                	<label>Tên đăng nhập</label>
                    <input type="text" name="name" class="form-control" placeholder="Tên đăng nhập" value="<?php echo e($user->name); ?>" />
                </div>

                <div class="form-group">
                	<label>Mật khẩu</label>
                    <input type="password" name="password" class="form-control" placeholder="Mật khẩu" value="<?php echo e($user->password); ?>" />
                </div>

                <div class="form-group">
                	<label>Nhập lại mật khẩu</label>
                    <input type="password" name="passAgain" class="form-control" placeholder="Mật khẩu" value="<?php echo e($user->password); ?>" />
                </div>

                <div class="form-group">
                	<label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e($user->email); ?>"  readonly=""/>
                </div>

                <input type="submit" name="submit" value="Lưu" class="btn btn-primary" />
            </form>
        </div>
    <div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/page/edit_info.blade.php ENDPATH**/ ?>