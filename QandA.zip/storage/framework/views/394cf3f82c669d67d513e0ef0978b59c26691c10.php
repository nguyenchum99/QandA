<?php $__env->startSection('content'); ?>

        <div style ="width: 40%; padding-left: 30px">
            <h2>Tạo phiên hỏi đáp</h2>
        	 
             <?php if(count($errors) > 0): ?>
             <div class="alert alert-danger">
             
                 <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($err); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             </div>
          <?php endif; ?>



            <form method="post" action="<?php echo e(url("user/manage/createsession")); ?>">
                
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                <div class="form-group">
                	<label>Tên phiên</label>
                    <input type="text" name="name" class="form-control" placeholder="Tên phiên"  />
                </div>

                <input type="submit" name="submit" value="Thêm mới" class="btn btn-primary" />
            </form>
        </div>
    <div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/manage/create_session.blade.php ENDPATH**/ ?>