<?php $__env->startSection('content'); ?>


<div class="main-right">
    <h2>Danh sách các câu hỏi</h2>
    <?php if(session('thongbao')): ?>

    <div class="alert alert-success">
        <?php echo e(session('thongbao')); ?>

    </div>

<?php endif; ?>

        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="box">
                <div class="row">  
                    <div class="col-md-2">
                        <img src="<?php echo e(URL::asset('/img/hoi-cham.jpg')); ?>" alt="image" 
                        style="height: 75px;width:75px;margin-top:10px" >
                    </div>
                    
                    <div class="col-md-10 box-right"><a href="<?php echo e(url("user/page/question_answer/{$l->id}")); ?>" style="text-decoration: none;">
                        <p class="title"><?php echo e($l->question); ?></p>
                        <p>Phiên hỏi-đáp: <?php echo e($l->name_session); ?></p>
                        <p class="time">Thời gian tạo: <?php echo e($l->created_at); ?></p>
                        </a>
                    </div>
                </div>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       
       
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.index_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/home/page/all_question.blade.php ENDPATH**/ ?>