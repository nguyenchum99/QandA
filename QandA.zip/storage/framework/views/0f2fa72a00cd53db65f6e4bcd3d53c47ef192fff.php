<?php $__env->startSection('content'); ?>
    
    <table class="table table-striped">
        <h4>Tìm kiếm: <?php echo e($tukhoa); ?></h4>
        <!-- <tr id="tbl-first-row">
            <td width="5%">id</td>
            <td width="30%" style="white-space: nowrap ;">Tên đăng nhập</td>
            <td width="30%">E-mail</td>
            <td width="20%">Mật khẩu</td>
            <td width="5%">Level</td>
        </tr>
 -->
        
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->id); ?></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?></td>
                <td><?php echo e($u->password); ?></td>
                <td>
                        <?php if($u->level == 1): ?>
                            <?php echo e("Admin"); ?>

                        <?php else: ?>
                            <?php echo e("User"); ?>

                        <?php endif; ?>
                </td>
                <td><a href="<?php echo e(url("admin/user/edit/{$u->id}")); ?>">Sửa</a></td>
                <td><a href="<?php echo e(url("admin/user/delete/{$u->id}")); ?>">Xóa</a></td>
            </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </table>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/user/search_user.blade.php ENDPATH**/ ?>