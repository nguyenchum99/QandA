<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LOGO</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="#">ĐĂNG NHẬP</a></li>
      <li><a href="#">GIỚI THIỆU</a></li>
      <li><a href="#">HƯỚNG DẪN</a></li>
      
    </ul>
  </div>
</nav>
<div class="container" style="background: #E9EBEE; height: 562px;">
    <center>

    <div class="Name">
        <h1>HỆ THỐNG HỎI - ĐÁP</h1>
        <span class="vien"></span>
    </div>

    <div class="login">
        <div class="main-head">
            <div class="head">
                <h3>ĐĂNG KÍ</h3>
            </div>
                <form action="">
                    <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Tên đăng nhập" name="name">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="E-mail" name="email">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Mật khẩu" name="password">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Nhập lại mật khẩu" name="cpassword">
                    </div>
                    <div class="form-group">
                        <input href="" type="submit" class="btn btn-primary" value="Đăng kí">
                    </div>
                    
                </form>
        </div> 
    </div>
</div></center>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\QandA\resources\views/home\user_register.blade.php ENDPATH**/ ?>