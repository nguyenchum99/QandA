<?php $__env->startSection('content'); ?>

        <div style ="width: 40%">
            <h2 style="color: blue">Tạo câu trả lời</h2>
            <h3>Câu hỏi: <?php echo e($question ->question); ?></h3>
        	 
             <?php if(count($errors) > 0): ?>
             <div class="alert alert-danger">
             
                 <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($err); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             </div>
          <?php endif; ?>

         <form method="post" action="<?php echo e($question->id); ?>">
             <div class="form-group">
                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>    
                 <textarea type="text" name="answer" rows="3"
                  class="form-control" placeholder="Nội dung câu trả lời"></textarea>
             </div>

             <input type="submit" name="submit" value="Thêm câu trả lời" class="btn btn-primary" />
         </form>
        </div>
    <div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/question/add_answer.blade.php ENDPATH**/ ?>