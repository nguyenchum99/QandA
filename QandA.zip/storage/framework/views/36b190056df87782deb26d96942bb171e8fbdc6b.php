<?php $__env->startSection('content'); ?>

        <div style ="width: 40%">
            <h2>Thêm thông tin người dùng</h2>
        	 
             <?php if(count($errors) > 0): ?>
             <div class="alert alert-danger">
             
                 <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($err); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             </div>
          <?php endif; ?>

         
         <?php if(session('thongbao')): ?>

             <div class="alert alert-success">
                 <?php echo e(session('thongbao')); ?>

             </div>

         <?php endif; ?>

            <form method="post" action="<?php echo e(url("admin/user/adduser")); ?>">

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                <div class="form-group">
                	<label>Tên đăng nhập</label>
                    <input type="text" name="name" class="form-control" placeholder="Tên đăng nhập"  />
                </div>

                <div class="form-group">
                	<label>Mật khẩu</label>
                    <input type="password" name="password" class="form-control" placeholder="Mật khẩu"  />
                </div>

                <div class="form-group">
                	<label>Nhập lại mật khẩu</label>
                    <input type="password" name="passAgain" class="form-control" placeholder="Mật khẩu" />
                </div>

                <div class="form-group">
                	<label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" />
                </div>

                <div class="form-group">
                    <label>Quyền người dùng</label>
                    <label class="radio-inline">
                        <input name="level" value="0" checked="" type="radio"> Người dùng
                    </label>

                    <label class="radio-inline">
                        <input name="level" value="1" type="radio">Admin
                    </label>
                    
                </div>

                <input type="submit" name="submit" value="Thêm mới" class="btn btn-primary" />
            </form>
        </div>
    <div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QandA\resources\views/admin/user/add_user.blade.php ENDPATH**/ ?>